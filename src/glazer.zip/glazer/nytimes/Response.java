package glazer.nytimes;

public class Response {
	Docs[] docs;

	public Docs[] getDocs() {
		return docs;
	}

	public void setDocs(Docs[] docs) {
		this.docs = docs;
	}

}
