package glazer.weather;

public class Main {
	private double temp;
	private double temp_min;
	private double temp_max;

	public double getTemp() {
		return temp;
	}

	public void setTemp(double temp) {
		this.temp = temp;
	}
	public void setTempMin(double temp_min) {
		this.temp_min = temp_min;
	}
	public void setTempMax(double temp_max) {
		this.temp_max = temp_max;
	}
	public double getTempMin() {
		return temp_min;
	}
	public double getTempMax() {
		return temp_max;
	}


}
