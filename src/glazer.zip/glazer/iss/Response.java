package glazer.iss;

public class Response {
private int risetime;

public int getRisetime() {
	return risetime;
}

public void setRisetime(int risetime) {
	this.risetime = risetime;
}
}
