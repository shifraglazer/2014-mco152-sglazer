package glazer.acm;

import static org.junit.Assert.*;

import org.junit.Test;

public class PenneyGameTest {

	@Test
	public void testPlayGame() {
		PenneyGame game=new PenneyGame();
		//game.playGame("4\n1\nHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHH\n2\nTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTT\n3\nHHTTTHHTTTHTHHTHHTTHTTTHHHTHTTHTTHTTTHTH\n4\nHTHTHHHTHHHTHTHHHHTTTHTTTTTHHTTTTHTHHHHT");
	}

}
