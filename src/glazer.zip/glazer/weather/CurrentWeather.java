package glazer.weather;

import java.io.IOException;

public class CurrentWeather {

	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub

		WeatherFrame frame = new WeatherFrame();
		frame.setVisible(true);

	}

}
