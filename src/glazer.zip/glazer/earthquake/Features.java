package glazer.earthquake;

public class Features {
	private Properties properties;

	public Properties getProperties() {
		return properties;
	}

	public void setPr(Properties properties) {
		this.properties = properties;
	}

}
